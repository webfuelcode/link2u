<nav class="navbar navbar-expand-lg navbar-light bg-white sticky" data-offset="500">
    <div class="container">
        
        <a class="navbar-brand" href="<?php echo e(route('welcome')); ?>">
            <?php echo e(config('app.name', 'Link2U')); ?>

        </a>

        <button class="navbar-toggler" data-toggle="collapse" data-target="#navbarContent" aria-controls="navbarContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="navbar-collapse collapse" id="navbarContent">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item <?php echo e(Request::is('/') ? 'active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(route('welcome')); ?>">Home</a>
                </li>
                <?php if(auth()->guard()->check()): ?>
                    <li class="nav-item <?php echo e(Request::is('home') ? 'active' : ''); ?>">
                        <a class="nav-link" href="<?php echo e(route('home')); ?>">Dashboard</a>
                    </li>
                <?php endif; ?>
                <li class="nav-item <?php echo e(Request::is('services') ? 'active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(route('welcomeservices')); ?>">Services</a>
                </li>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['isAdmin', 'isModerator'])): ?>
                <li class="nav-item">
                    <a class="btn btn-success ml-lg-2" href="<?php echo e(route('admin')); ?>"><?php echo e(Str::upper(Auth::user()->role)); ?></a>
                </li>
                <?php endif; ?>
                <li class="nav-item">
                    <a class="btn btn-primary ml-lg-2" href="<?php echo e($admin->toplink); ?>"><?php echo e($admin->toptext); ?></a>
                </li>
                <?php if(auth()->guard()->guest()): ?>
                    <li class="nav-item <?php echo e(Request::is('login') ? 'active' : ''); ?>">
                        <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                    </li>
                    <?php if(Route::has('register')): ?>
                        <li class="nav-item <?php echo e(Request::is('register') ? 'active' : ''); ?>">
                            <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                        </li>
                    <?php endif; ?>
                <?php else: ?>
                    <li class="nav-item dropdown">
                        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                            <?php echo e(Auth::user()->name); ?>

                        </a>

                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                            <a href="<?php echo e(route('useredit')); ?>" class="dropdown-item">
                                User settings
                            </a>
                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                onclick="event.preventDefault();
                                                document.getElementById('logout-form').submit();">
                                <?php echo e(__('Logout')); ?>

                            </a>

                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                <?php echo csrf_field(); ?>
                            </form>
                        </div>
                    </li>
                <?php endif; ?>
        </ul>
      </div>

    </div>
  </nav><?php /**PATH C:\xamppi\htdocs\Link2U\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>