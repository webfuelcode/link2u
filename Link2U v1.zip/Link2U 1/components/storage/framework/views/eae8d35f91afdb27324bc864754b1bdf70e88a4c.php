<?php $__env->startSection('title', 'Welcome'); ?>

<?php $__env->startSection('content'); ?>
  <div class="page-section banner-seo-check">
    <div class="wrap bg-image" style="background-image: url(../assets/img/bg_pattern.svg);">
      <div class="container text-center">
        <div class="row justify-content-center wow fadeInUp">
          <div class="col-lg-8">
            <h2 class="mb-4">Put the URL to shorten</h2>
            <form action="<?php echo e(route('generate')); ?>" method="POST">
              <?php echo csrf_field(); ?>
              <input type="text" class="form-control" name="link" placeholder="E.g google.com/services/web/20-22-09-76-1000-ZxcVwvtuOpmklJGH">
              <button type="submit" class="btn btn-success">Shorten Now</button>
            </form>
            
          </div>
        </div>
      </div> <!-- .container -->
    </div> <!-- .wrap -->
  </div> <!-- .page-section -->
  <?php echo $__env->make('layouts.msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  
<div class="page-section" id="about">
    <div class="container">
      <div class="row align-items-center">
        <div class="col-lg-6 py-3 wow fadeInUp">
          <span class="subhead">About us</span>
          <h2 class="title-section">Link shorten service</h2>
          <div class="divider"></div>

          <p>Convert long link into a short link to make it easy to share on twitter and through SMS. Keep your all links in a place, so you can find all those for future purposes.</p>
          <p>Add new and just delete from the database.</p>
          <a href="<?php echo e(route('login')); ?>" class="btn btn-primary mt-3">Sign-in now</a>
        </div>
        <div class="col-lg-6 py-3 wow fadeInRight">
          <div class="img-fluid py-3 text-center">
            <img src="../assets/img/about_frame.png" alt="">
          </div>
        </div>
      </div>
    </div> <!-- .container -->
  </div> <!-- .page-section -->

  <div class="text-center img-fluid">
    <?php echo $admin->advertise; ?>

  </div>

  <div class="page-section">
    <div class="container">
      <div class="text-center wow fadeInUp">
        <div class="subhead">Servicdes we recommend</div>
        <h2 class="title-section">We offer</h2>
        <div class="divider mx-auto"></div>
        <a href="<?php echo e(route('welcomeservices')); ?>">See more</a>
      </div>
      <div class="row">
        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-lg-4">
            <div class="card-service wow fadeInUp">
              <div class="header">
                <img src="../assets/img/services/service-1.svg" alt="">
              </div>
              <div class="body">
                <h5 class="text-secondary"><?php echo e($item->title); ?></h5>
                <p><?php echo e($item->body); ?></p>
                <a href="<?php echo e($item->link); ?>" target="_blank" class="btn btn-primary">Read More</a>
              </div>
            </div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div> <!-- .container -->
  </div> <!-- .page-section -->

  <div class="page-section">
    <div class="container">
      <div class="text-center wow fadeInUp img-fluid">
          <?php if(!empty($admin->advertise)): ?>
            <?php echo $admin->advertise; ?>

          <?php else: ?>
            <a href="https://www.wall-spot.com/likes/hostinger" target="_blank"><img src="/image/hostingeren-728x90.png" class="img-fluid" alt="Reliable web hosting service"></a>
          <?php endif; ?>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppi\htdocs\Link2U\resources\views/welcome.blade.php ENDPATH**/ ?>