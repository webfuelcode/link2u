
<?php $__env->startSection('title', 'Services'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="page-banner">
      <div class="row justify-content-center align-items-center h-100">
        <div class="col-md-6">
          <h1 class="text-center">Services</h1>
        </div>
      </div>
    </div>
</div>

<div class="text-center mb-4">
  <?php if(!empty($admin->advertise)): ?>
    <?php echo $admin->advertise; ?>

  <?php else: ?>
    <a href="https://www.wall-spot.com/likes/hostinger" target="_blank"><img src="/image/hostingeren-728x90.png" class="img-fluid" alt="Reliable web hosting service"></a>
  <?php endif; ?>
</div>

<div class="container">
  <?php echo e($admin->servicedes); ?>

</div>


  <div class="container">
    <div class="row align-items-center">
      <div class="col-lg-12 py-2">
        
        <div class="page-section">
            <div class="container">
              <div class="row">
                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="col-lg-4">
                    <div class="card-service wow fadeInUp">
                      <div class="header">
                        <img src="<?php echo e(asset('image')); ?>/<?php echo e($item->icon); ?>" alt="<?php echo e($item->title); ?>" width="150px">
                      </div>
                      <div class="body">
                        <h5 class="text-secondary"><?php echo e($item->title); ?></h5>
                        <p><?php echo e($item->body); ?></p>
                        <a href="<?php echo e($item->link); ?>" target="_blank" class="btn btn-primary">Open it!</a>
                      </div>
                    </div>
                  </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
            </div> <!-- .container -->
          </div> <!-- .page-section -->
      </div>
    </div>
  </div> <!-- .container -->


  <div class="container mb-4">
    <div class="text-center img-fluid">
      <?php if(!empty($admin->advertise)): ?>
        <?php echo $admin->advertise; ?>

      <?php else: ?>
        <a href="https://www.wall-spot.com/likes/hostinger" target="_blank"><img src="/image/hostingeren-728x90.png" class="img-fluid" alt="Reliable web hosting service"></a>
      <?php endif; ?>
    </div>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppi\htdocs\Link2U\resources\views/service.blade.php ENDPATH**/ ?>