
<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="copyright" content="https://www.wall-spot.com">
  <meta name="distributor" content="https://webfuelcode.wall-spot.com">

  <meta http-equiv="X-UA-Compatible" content="ie=edge">

  <!-- CSRF Token -->
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

  <title><?php echo e(config('app.name', 'Link2U')); ?> | <?php echo $__env->yieldContent('title'); ?></title>
  <link rel="shortcut icon" href="<?php echo e(asset('image/favicon.png')); ?>" />
  
  <!-- Scripts -->
  <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

  <title>SeoGram - SEO Agency Template</title>

  <link rel="stylesheet" href="<?php echo e(asset('assets/css/maicons.css')); ?>">

  <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.css')); ?>">

  <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/animate/animate.css')); ?>">

  <link rel="stylesheet" href="<?php echo e(asset('assets/css/theme.css')); ?>">

</head>
<body>

  <!-- Back to top button -->
  <div class="back-to-top"></div>

  <header>
    <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
  </header>

  <?php echo $__env->yieldContent('content'); ?>

  <footer class="page-footer bg-image" style="background-image: url(../assets/img/world_pattern.svg);">
    <div class="container">
      <div class="row mb-5">
        <div class="col-lg-5 py-3">
          <h3><?php echo e(config('app.name', $admin->sitename)); ?></h3>
          <p><?php echo e($admin->sitedes); ?></p>

          <div class="social-media-button">
            <?php if(!empty($admin->facebook)): ?>
              <a href="https://www.facebook.com/<?php echo e($admin->facebook); ?>"><span class="mai-logo-facebook-f"></span></a>
            <?php endif; ?>
            <?php if(!empty($admin->twitter)): ?>
              <a href="https://twitter.com/<?php echo e($admin->twitter); ?>"><span class="mai-logo-twitter"></span></a>
            <?php endif; ?>
            <?php if(!empty($admin->linkedin)): ?>
              <a href="https://linkedin.com/<?php echo e($admin->linkedin); ?>"><span class="mai-logo-linkedin"></span></a>
            <?php endif; ?>
            <?php if(!empty($admin->instagram)): ?>
              <a href="https://instagram.com/<?php echo e($admin->instagram); ?>"><span class="mai-logo-instagram"></span></a>
            <?php endif; ?>
            <?php if(!empty($admin->youtube)): ?>
              <a href="https://youtube.com/<?php echo e($admin->youtube); ?>"><span class="mai-logo-youtube"></span></a>
            <?php endif; ?>
          </div>
        </div>
        <div class="col-lg-3 py-3">
          <h5><?php echo e($admin->col2); ?></h5>
          <ul class="footer-menu">
            <?php $__empty_1 = true; $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <li><a href="<?php echo e(route('pageshow', $item->slug)); ?>"><?php echo e($item->name); ?></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <li><a href="https://www.wall-spot.com">Tech Blog</a></li>
                <li><a href="https://webfuelcode.wall-spot.com">PHP Script</a></li>
            <?php endif; ?>
          </ul>
        </div>
        <div class="col-lg-4 py-3">
          <h5><?php echo e($admin->col3); ?></h5>
          <p><?php echo e($admin->col3s1); ?></p>
          <p><?php echo e($admin->col3s2); ?></p>
          <p><?php echo e($admin->col3s3); ?></p>
        </div>
      </div>

      <p class="text-center" id="copyright">Copyright &copy; <?php echo e(date('Y')); ?>. Develop by <a href="https://webfuelcode.wall-spot.com/" target="_blank">WebFuelCode</a></p>
    </div>
  </footer>

<script src="<?php echo e(asset('assets/js/jquery-3.5.1.min.js')); ?>"></script>

<script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>

<script src="<?php echo e(asset('assets/js/google-maps.js')); ?>"></script>

<script src="<?php echo e(asset('assets/vendor/wow/wow.min.js')); ?>"></script>

<script src="<?php echo e(asset('assets/js/theme.js')); ?>"></script>
  
</body>
</html><?php /**PATH C:\xamppi\htdocs\Link2U\resources\views/layouts/app.blade.php ENDPATH**/ ?>