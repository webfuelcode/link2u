<?php $__env->startSection('title'); ?>
    Member's dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-section banner-seo-check">
    <div class="wrap bg-image" style="background-image: url(../assets/img/bg_pattern.svg);">
      <div class="container text-center">
        <div class="row justify-content-center wow fadeInUp">
          <div class="col-lg-8">
            <h2 class="mb-4">Put the URL to shorten</h2>
            <form action="<?php echo e(route('generate')); ?>" method="POST">
              <?php echo csrf_field(); ?>
              <input type="text" class="form-control" name="link" placeholder="E.g https://google.com/services/web/20-22-09-76-1000-ZxcVwvtuOpmklJGH">
              <button type="submit" class="btn btn-success">Shorten Now</button>
            </form>
            
          </div>
        </div>
      </div> <!-- .container -->
    </div> <!-- .wrap -->
</div> <!-- .page-section -->
<?php echo $__env->make('layouts.msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container">
    
    

    <div class="row align-items-center">
        <div class="col-lg-12 py-3">
          <span class="subhead"><?php echo e(__('Dashboard')); ?></span>
          <div class="text-center mb-4">
            <?php if(!empty($admin->advertise)): ?>
              <?php echo $admin->advertise; ?>

            <?php else: ?>
              <a href="https://www.wall-spot.com/likes/hostinger" target="_blank"><img src="/image/hostingeren-728x90.png" class="img-fluid" alt="Reliable web hosting service"></a>
            <?php endif; ?>
          </div>
          <h2 class="title-section">Latest links</h2>
          <div class="divider"></div>

          <div class="table-responsive">
            <table class="table">
              <tr>
                  <th>Links</th>
                  <th>Short links</th>
                  <th>Created</th>
                  <th>Delete</th>
              </tr>
              <?php $__empty_1 = true; $__currentLoopData = $shortLinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                  <tr>
                      <td><?php echo Str::limit($item->link, 27); ?></td>
                      <td><?php echo e(url('/')); ?>/<?php echo e($item->code); ?></td>
                      <td><?php echo e($item->created_at->diffForHumans()); ?></td>
                      <td>
                        <div class="link2u-btn">
                          <a href="#" data-toggle="modal" data-target="#delete<?php echo e($item->id); ?>"><i class="mai-trash-bin"></i></a>
                        </div>
                        <?php echo $__env->make('layouts.modal.shorten_delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                      </td>
                  </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                  <p class="text-danger px-3">You have not created any short links yet!</p>
              <?php endif; ?>
            </table>
            <?php echo e($shortLinks->links()); ?>

          </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppi\htdocs\Link2U\resources\views/home.blade.php ENDPATH**/ ?>