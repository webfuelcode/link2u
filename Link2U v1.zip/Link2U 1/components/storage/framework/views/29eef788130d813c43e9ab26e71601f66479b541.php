
<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-3 mb-4 stretch-card transparent">
      <div class="card card-tale">
        <div class="card-body">
          <p class="mb-4">Members (30 days)</p>
          <p class="fs-30 mb-2"><?php echo e($this_month_mem); ?></p>
          <p><?php echo e($ucount); ?> (Total Members)</p>
        </div>
      </div>
    </div>
    <div class="col-md-3 mb-4 stretch-card transparent">
      <div class="card card-dark-blue">
        <div class="card-body">
          <p class="mb-4">Links (30 days)</p>
          <p class="fs-30 mb-2"><?php echo e($this_month_links); ?></p>
          <p><?php echo e($lcount); ?> (Total links)</p>
        </div>
      </div>
    </div>
    <div class="col-md-3 mb-4 stretch-card transparent">
        <div class="card card-light-blue">
          <div class="card-body">
            <p class="mb-4">Shorten by members (30 days)</p>
            <p class="fs-30 mb-2"><?php echo e($this_month_links_mem); ?></p>
            <p><?php echo e($ulcount); ?> (Members links)</p>
          </div>
        </div>
    </div>
    <div class="col-md-3 mb-4 stretch-card transparent">
        <div class="card card-light-danger">
          <div class="card-body">
            <p class="mb-4">Shorten by anonym (30 days)</p>
            <p class="fs-30 mb-2"><?php echo e($this_month_links_anonym); ?></p>
            <p><?php echo e($alcount); ?> (Anonym links)</p>
          </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-3 mb-4 stretch-card transparent">
        <div class="card bg-success">
            <div class="card-body text-light">
                <p class="mb-4">Short links today</p>
                <p class="fs-30 mb-2"><?php echo e($daylinks); ?></p>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-4 stretch-card transparent">
        <div class="card bg-success">
            <div class="card-body text-light">
                <p class="mb-4">Short links (7 days)</p>
                <p class="fs-30 mb-2"><?php echo e($weeklinks); ?></p>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-4 stretch-card transparent">
        <div class="card bg-success">
            <div class="card-body text-light">
                <p class="mb-4">Short links (15 days)</p>
                <p class="fs-30 mb-2"><?php echo e($fifteenlinks); ?></p>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-4 stretch-card transparent">
        <div class="card bg-success">
            <div class="card-body text-light">
                <p class="mb-4">Short links (60 days)</p>
                <p class="fs-30 mb-2"><?php echo e($amonthlinks); ?></p>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-5 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <p class="card-title mb-0">Members</p>
                <div class="table-responsive">
                    <table class="table table-striped table-borderless">
                        <thead>
                            <th>Name</th>
                            <th>Joined</th>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($item->name); ?></td>
                                    <td><?php echo e($item->created_at->diffForHumans()); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-7 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <p class="card-title mb-0">Recent links</p>
                <div class="table-responsive">
                    <table class="table table-striped table-borderless">
                    <thead>
                        <tr>
                        <th>Shorten</th>
                        <th>Links</th>
                        </tr>  
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $shorten; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e(url('/')); ?>/<?php echo e($item->code); ?></td>
                                <td><?php echo Str::limit($item->link, 27); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            
                        <?php endif; ?>
                    </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppi\htdocs\Link2U\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>